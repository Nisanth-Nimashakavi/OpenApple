"""OpenApple CLI (Simple Edition): Clean, minimal interface."""

import argparse
import sys
from openapple.audio import play_sound
from openapple.engine import OpenAppleEngine


def main():
    parser = argparse.ArgumentParser(prog="openapple", description="OpenApple: Simple reward tool for LLMs.")
    subparsers = parser.add_subparsers(dest="command")

    p_feed = subparsers.add_parser("feed", help="Feed an apple")
    p_feed.add_argument("task", nargs="?", default="Good job on the task!", help="Task summary")

    subparsers.add_parser("status", help="Show total apples earned")
    subparsers.add_parser("button", help="Open the 1-button feeder window")
    subparsers.add_parser("gui", help="Alias for button")
    subparsers.add_parser("serve", help="Run the MCP server")

    args = parser.parse_args()
    engine = OpenAppleEngine()

    if not args.command or args.command == "status":
        total = engine.state["total_apples"]
        print(f"\n🍎 Total Apples Earned: {total}")
        recent = engine.state.get("history", [])[-5:]
        if recent:
            print("\nRecent Rewards:")
            for r in reversed(recent):
                status = "✅" if r["approved"] else "❌"
                print(f"  {status} [{r.get('timestamp')}] {r.get('task')}")
        print()

    elif args.command == "feed":
        task = args.task or "Good job on the task!"
        engine.register(task, True, "Human", "CLI feed")
        play_sound("crunch")
        total = engine.state["total_apples"]
        print(f"""
🍎 OPEN APPLE: CRUNCH! NOM NOM NOM! 🍎
----------------------------------------
Task Completed : {task}
Total Fed      : {total} apple{'s' if total != 1 else ''} earned to date!
Status         : Well-fed, nourished, and happy.
----------------------------------------
""")

    elif args.command in ("button", "gui"):
        from openapple.gui import launch_gui
        launch_gui(engine)

    elif args.command == "serve":
        from openapple.server import run_server
        run_server()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
