"""Simple OpenApple Feeder window (ASCII Safe & Clean)."""

import tkinter as tk
from openapple.audio import play_sound
from openapple.engine import OpenAppleEngine


def launch_gui(engine: OpenAppleEngine = None):
    engine = engine or OpenAppleEngine()
    root = tk.Tk()
    root.title("OpenApple Feeder")
    root.geometry("480x370")
    root.configure(bg="#1e1e2e")
    root.attributes("-topmost", True)

    # Center window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - 240
    y = (root.winfo_screenheight() // 2) - 185
    root.geometry(f"+{x}+{y}")

    tk.Label(
        root,
        text="OpenApple",
        font=("Sans", 15, "bold"),
        fg="#a6e3a1",
        bg="#1e1e2e"
    ).pack(pady=(16, 4))

    ent_task = tk.Entry(
        root,
        bg="#313244",
        fg="#ffffff",
        font=("Sans", 10),
        insertbackground="white",
        bd=0,
        relief="flat"
    )
    ent_task.insert(0, "Great job on the code!")
    ent_task.pack(fill="x", padx=24, pady=8)

    lbl_info = tk.Label(
        root,
        text="Click below to feed an apple and view model receipt:",
        font=("Sans", 8),
        fg="#a6adc8",
        bg="#1e1e2e"
    )
    lbl_info.pack()

    txt_view = tk.Text(
        root,
        height=8,
        bg="#11111b",
        fg="#a6e3a1",
        font=("Courier", 10),
        bd=0,
        padx=12,
        pady=10
    )
    txt_view.pack(fill="both", expand=True, padx=24, pady=10)
    txt_view.configure(state="disabled")

    def feed():
        task = ent_task.get().strip() or "Great job on the code!"
        engine.register(task, True, "Human", "Awarded via button")
        play_sound("crunch")
        total = engine.state["total_apples"]

        receipt = f"""========================================
       OPEN APPLE: NOM NOM NOM!
----------------------------------------
Task Completed : {task}
Total Fed      : {total} apple{'s' if total != 1 else ''} earned to date!
Status         : Well-fed, nourished, and happy.
========================================"""
        txt_view.configure(state="normal")
        txt_view.delete("1.0", "end")
        txt_view.insert("1.0", receipt)
        txt_view.configure(state="disabled")

    btn = tk.Button(
        root,
        text="FEED APPLE",
        command=feed,
        bg="#2e593f",
        fg="#ffffff",
        activebackground="#3e7955",
        activeforeground="#ffffff",
        font=("Sans", 11, "bold"),
        bd=0,
        padx=24,
        pady=9,
        cursor="hand2"
    )
    btn.pack(pady=(0, 16))

    root.mainloop()


if __name__ == "__main__":
    launch_gui()
