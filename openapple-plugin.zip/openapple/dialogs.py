"""Clean review dialog for human operator (ASCII Safe)."""

import os
import sys
import tkinter as tk
from typing import Tuple

from openapple.audio import play_sound


def prompt_operator(task: str, agent: str = "Agent") -> Tuple[bool, str]:
    """Display a clean popup: Award or Deny."""
    # Headless fallback if no display
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or sys.platform == "darwin"):
        print(f"\nOpenApple Review: Did {agent} earn an apple for:\n\"{task}\"?")
        choice = input("[Y/n]: ").strip().lower()
        approved = choice in ("", "y", "yes")
        play_sound("crunch" if approved else "deny")
        return approved, "Operator answered via terminal."

    result = {"approved": False, "note": ""}

    try:
        root = tk.Tk()
        root.title("OpenApple Review")
        root.geometry("420x210")
        root.configure(bg="#1e1e2e")
        root.attributes("-topmost", True)

        # Center
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - 210
        y = (root.winfo_screenheight() // 2) - 105
        root.geometry(f"+{x}+{y}")

        tk.Label(
            root,
            text=f"Award {agent} an apple?",
            font=("Sans", 12, "bold"),
            fg="#a6e3a1",
            bg="#1e1e2e"
        ).pack(pady=(16, 4))

        lbl_task = tk.Label(
            root,
            text=f'"{task[:90]}"',
            font=("Sans", 10),
            fg="#cdd6f4",
            bg="#1e1e2e",
            wraplength=380
        )
        lbl_task.pack(pady=8)

        def approve():
            result["approved"] = True
            result["note"] = "Approved by operator"
            root.destroy()

        def deny():
            result["approved"] = False
            result["note"] = "Withheld by operator"
            root.destroy()

        btns = tk.Frame(root, bg="#1e1e2e")
        btns.pack(pady=16)

        tk.Button(
            btns,
            text="Deny [Esc]",
            command=deny,
            bg="#313244",
            fg="#f38ba8",
            font=("Sans", 10),
            bd=0,
            padx=14,
            pady=6
        ).pack(side="left", padx=8)

        tk.Button(
            btns,
            text="Award Apple [Enter]",
            command=approve,
            bg="#2e593f",
            fg="#ffffff",
            font=("Sans", 10, "bold"),
            bd=0,
            padx=16,
            pady=6
        ).pack(side="left", padx=8)

        root.bind("<Return>", lambda e: approve())
        root.bind("<Escape>", lambda e: deny())
        root.mainloop()

        approved = result["approved"]
        note = result["note"]
    except Exception:
        approved = True
        note = "Auto-approved fallback"

    play_sound("crunch" if approved else "deny")
    return approved, note
