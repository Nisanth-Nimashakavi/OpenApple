#!/usr/bin/env bash
# OpenApple One-Click Installer for Linux & macOS
set -e

echo "🍎 Installing OpenApple..."

# Detect Python
if command -v python3 >/dev/null 2>&1; then
    PY_BIN="python3"
elif command -v python >/dev/null 2>&1; then
    PY_BIN="python"
else
    echo "❌ Error: Python 3 is required but not found."
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Install package
if command -v uv >/dev/null 2>&1; then
    echo "⚡ Installing with uv..."
    uv pip install -e . || pip install -e .
else
    echo "📦 Installing with pip..."
    pip install -e .
fi

# Ensure ~/.local/bin is in PATH and linked
mkdir -p "$HOME/.local/bin"
if [ -f "$HOME/.venv/bin/openapple" ]; then
    ln -sf "$HOME/.venv/bin/openapple" "$HOME/.local/bin/openapple"
    ln -sf "$HOME/.venv/bin/openapple-server" "$HOME/.local/bin/openapple-server"
fi

# Run automated agent configuration
if command -v openapple >/dev/null 2>&1; then
    openapple install all
    openapple doctor
else
    "$PY_BIN" -m openapple.cli install all
    "$PY_BIN" -m openapple.cli doctor
fi

echo "✨ OpenApple installation complete!"
