"""Simple test suite for OpenApple."""

from unittest.mock import patch
from openapple.engine import OpenAppleEngine
from openapple.server import petition_for_apple, view_orchard


def test_engine_register(tmp_path):
    ledger = tmp_path / "ledger.json"
    engine = OpenAppleEngine(data_path=ledger)
    assert engine.state["total_apples"] == 0

    engine.register("Fixed bug", True)
    assert engine.state["total_apples"] == 1

    engine.register("Bad code", False)
    assert engine.state["total_apples"] == 1
    assert len(engine.state["history"]) == 2


def test_server_tools():
    with patch("openapple.server.prompt_operator", return_value=(True, "Approved")):
        res = petition_for_apple("Wrote tests")
        assert "OPEN APPLE: CRUNCH!" in res
        assert "Total Fed" in res

    orchard = view_orchard()
    assert "Total Apples Earned" in orchard
